import React, { useState, useRef, useEffect } from 'react';
import { Send, ThumbsUp, ThumbsDown, AlertTriangle, CheckCircle, XCircle, BarChart3, Download, Trash2, Settings } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid'; // For generating unique conversation IDs

export default function EnergyIncidentChatbot() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [role, setRole] = useState('auto'); // 'auto', 'operator', 'engineer'
  const [showSettings, setShowSettings] = useState(false);
  const [conversationId, setConversationId] = useState(uuidv4()); // Unique ID for the current conversation session
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = {
      id: Date.now(),
      role: 'user',
      content: input,
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('http://127.0.0.1:8000/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: userMessage.content,
          conversation_id: conversationId,
          role: role // Send the selected role to the backend
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const aiResponse = await response.json();
      setMessages(prev => [...prev, { ...aiResponse, timestamp: new Date().toLocaleTimeString() }]);
    } catch (error) {
      console.error("Error sending message to backend:", error);
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        role: 'assistant',
        content: `Error: Could not connect to the backend or process your request. Please ensure the backend server is running and try again. (${error.message})`,
        timestamp: new Date().toLocaleTimeString(),
        riskScore: 0, riskColor: 'gray', category: 'Error', leadProb: 0, similarIncidents: [], leadFeatures: []
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleFeedback = (messageId, type) => {
    setMessages(prev =>
      prev.map(msg =>
        msg.id === messageId ? { ...msg, feedback: type } : msg
      )
    );
    // TODO: Implement actual feedback submission to backend
    console.log(`Feedback for message ${messageId}: ${type}`);
  };

  const clearChat = () => {
    setMessages([]);
    setConversationId(uuidv4()); // Generate a new conversation ID for a fresh chat
  };

  const getRiskColorClass = (color) => {
    switch(color) {
      case 'red': return 'bg-red-500';
      case 'yellow': return 'bg-yellow-500';
      case 'green': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-80 bg-white border-r border-gray-200 p-4 flex flex-col">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-blue-600">⚡ Energy AI</h1>
            <p className="text-sm text-gray-500">Incident Assistant</p>
          </div>
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <Settings className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {showSettings && (
          <div className="mb-4 p-3 bg-gray-50 rounded-lg">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              User Role
            </label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            >
              <option value="auto">Auto-detect</option>
              <option value="operator">Operator</option>
              <option value="engineer">Engineer</option>
            </select>
          </div>
        )}

        <div className="space-y-3 mb-6">
          <div className="p-3 bg-blue-50 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Total Incidents</span>
              <span className="text-xl font-bold text-blue-600">1,247</span>
            </div>
          </div>
          <div className="p-3 bg-green-50 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Avg Response</span>
              <span className="text-xl font-bold text-green-600">2.3s</span>
            </div>
          </div>
          <div className="p-3 bg-purple-50 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Uptime</span>
              <span className="text-xl font-bold text-purple-600">99.8%</span>
            </div>
          </div>
        </div>

        <div className="flex-1" />

        <div className="space-y-2">
          <button
            onClick={clearChat}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            Clear Chat
          </button>
          <button className="w-full flex items-center justify-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
            <Download className="w-4 h-4" />
            Export History
          </button>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <h2 className="text-xl font-semibold text-gray-800">
            Energy Incident Knowledge Base
          </h2>
          <p className="text-sm text-gray-500">
            Ask about incidents, equipment failures, or anomaly detection
          </p>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {messages.length === 0 && (
            <div className="text-center mt-20">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                <AlertTriangle className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">
                Welcome to Energy Incident Assistant
              </h3>
              <p className="text-gray-600 max-w-md mx-auto">
                Describe an incident, ask about past resolutions, or submit numerical data for anomaly detection
              </p>
            </div>
          )}

          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-3xl ${ 
                  message.role === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white border border-gray-200'
                } rounded-lg p-4 shadow-sm`}
              >
                {message.role === 'assistant' && message.riskScore !== undefined && (
                  <div className="mb-3 pb-3 border-b border-gray-200">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${getRiskColorClass(message.riskColor)}`} />
                        <span className="text-sm font-semibold text-gray-700">
                          Risk Score: {Math.round(message.riskScore)}/100
                        </span>
                      </div>
                      <span className="text-xs px-2 py-1 bg-gray-100 rounded text-gray-600">
                        {message.category}
                      </span>
                      {message.leadProb !== undefined && (
                        <span className="text-xs px-2 py-1 bg-purple-100 rounded text-purple-700">
                          LEAD: {Math.round(message.leadProb * 100)}%
                        </span>
                      )}
                    </div>
                  </div>
                )}

                <div className={`prose prose-sm max-w-none ${message.role === 'user' ? 'text-white' : 'text-gray-800'}`}>
                  {message.content.split('\n').map((line, i) => {
                    if (line.startsWith('**') && line.endsWith('**')) {
                      return <h4 key={i} className="font-bold mt-3 mb-1">{line.replace(/\*\*/g, '')}</h4>;
                    }
                    if (line.match(/^\s*-\s/)) { // Handle bullet points
                      return <li key={i} className="my-0.5 ml-4">{line.substring(line.indexOf('-') + 1).trim()}</li>;
                    }
                    return <p key={i} className="my-1">{line}</p>;
                  })}
                </div>

                {message.role === 'assistant' && message.similarIncidents && message.similarIncidents.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-gray-200">
                    <details className="text-sm">
                      <summary className="cursor-pointer font-semibold text-gray-700">
                        📚 Similar Incidents
                      </summary>
                      <div className="mt-2 space-y-1">
                        {message.similarIncidents.map((inc) => (
                          <div key={inc.id} className="text-xs text-gray-600">
                            • <span className="font-mono">{inc.incident_id}</span> ({(inc.score * 100).toFixed(0)}%): {inc.summary}
                          </div>
                        ))}
                      </div>
                    </details>
                  </div>
                )}

                {message.role === 'assistant' && (
                  <div className="flex items-center gap-2 mt-3 pt-3 border-t border-gray-200">
                    <button
                      onClick={() => handleFeedback(message.id, 'up')}
                      className={`p-1.5 rounded hover:bg-gray-100 transition-colors ${ 
                        message.feedback === 'up' ? 'bg-green-100 text-green-600' : 'text-gray-500'
                      }`}
                    >
                      <ThumbsUp className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleFeedback(message.id, 'down')}
                      className={`p-1.5 rounded hover:bg-gray-100 transition-colors ${ 
                        message.feedback === 'down' ? 'bg-red-100 text-red-600' : 'text-gray-500'
                      }`}
                    >
                      <ThumbsDown className="w-4 h-4" />
                    </button>
                    <span className="text-xs text-gray-500 ml-auto">{message.timestamp}</span>
                  </div>
                )}

                {message.role === 'user' && (
                  <div className="text-xs text-blue-200 mt-2">{message.timestamp}</div>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex justify-start">
              <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="bg-white border-t border-gray-200 px-6 py-4">
          <div className="flex gap-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Describe the incident or ask a question..."
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              onClick={handleSend}
              disabled={loading || !input.trim()}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              Send
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            Press Enter to send • Role: {role === 'auto' ? 'Auto-detect' : role.charAt(0).toUpperCase() + role.slice(1)}
          </p>
        </div>
      </div>
    </div>
  );
}