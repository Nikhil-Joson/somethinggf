import subprocess
import sys
import atexit
import os
import platform

# List to keep track of running processes
processes = []

def cleanup():
    """
    Terminates all running subprocesses when the script exits.
    """
    print("Shutting down all services...")
    for p in processes:
        try:
            p.terminate()
            p.wait(timeout=5) # Wait for 5 seconds for graceful shutdown
        except subprocess.TimeoutExpired:
            p.kill() # Force kill if it doesn't terminate
    print("Shutdown complete.")

# Register the cleanup function to be called on script exit
atexit.register(cleanup)

def run_command(command, cwd, name):
    """
    Starts a command as a subprocess and pipes its output.
    """
    print(f"--- Starting {name} ---")
    print(f"Running command: '{' '.join(command)}' in directory: '{cwd}'")
    
    try:
        # For Windows, 'npm' is often a .cmd file which requires shell=True
        use_shell = platform.system() == "Windows"
        
        process = subprocess.Popen(
            command,
            cwd=cwd,
            stdout=sys.stdout,
            stderr=sys.stderr,
            shell=use_shell
        )
        processes.append(process)
        print(f"--- {name} started successfully with PID: {process.pid} ---")
        return process
    except FileNotFoundError:
        print(f"Error: Command '{command[0]}' not found. Please ensure it is installed and in your system's PATH.")
        sys.exit(1)
    except Exception as e:
        print(f"An error occurred while starting the {name}: {e}")
        sys.exit(1)

def main():
    """
    Main function to start backend and frontend servers.
    """
    # --- Start Backend Server ---
    backend_dir = os.path.join(os.path.dirname(__file__), "backend")
    backend_command = [sys.executable, "main.py"]
    run_command(backend_command, backend_dir, "Backend Server")

    # --- Start Frontend Server ---
    frontend_dir = os.path.join(os.path.dirname(__file__), "frontend")
    frontend_command = ["npm", "run", "dev"]
    run_command(frontend_command, frontend_dir, "Frontend Server")

    print("\nBackend and Frontend servers are running.")
    print("View Frontend at: http://localhost:5173 (or the address shown above)")
    print("Backend is running on: http://127.0.0.1:8000")
    print("Press Ctrl+C to shut down both servers.")

    # Keep the main script alive and wait for processes to exit
    try:
        for p in processes:
            p.wait()
    except KeyboardInterrupt:
        # The atexit handler will be called automatically.
        print("\nCtrl+C received. Shutting down...")
        sys.exit(0)

if __name__ == "__main__":
    # First, check if the required directories exist
    if not os.path.isdir("backend") or not os.path.isdir("frontend"):
        print("Error: 'backend' and 'frontend' directories not found in the current location.")
        print("Please run this script from the root directory of the project.")
        sys.exit(1)
        
    main()
