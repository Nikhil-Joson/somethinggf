# Setup Instructions for Energy Incident Chatbot

This document outlines the steps to set up and run the Energy Incident Chatbot application.

## 1. Backend Setup

### 1.1. Environment Variables

Create a `.env` file in the `backend/` directory with your Azure OpenAI API credentials:

```
AZURE_OPENAI_API_KEY=YOUR_API_KEY
AZURE_OPENAI_ENDPOINT=YOUR_API_ENDPOINT
AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME=text-embedding-ada-002
AZURE_OPENAI_CHAT_DEPLOYMENT_NAME=gpt-4o
```
Replace `YOUR_API_KEY` and `YOUR_API_ENDPOINT` with your actual Azure OpenAI credentials.

### 1.2. Install Python Dependencies

Navigate to the `backend/` directory and install the required Python packages:

```bash
cd backend
pip install -r requirements.txt
```

### 1.3. Data Ingestion

Run the ingestion script to populate the ChromaDB knowledge base. This will create a `chroma_db` directory in your `backend/` folder.

```bash
python ingest.py
```

### 1.4. Start Backend Server

Start the FastAPI backend server:

```bash
python main.py
```
The server will run on `http://127.0.0.1:8000`.

## 2. Frontend Setup

### 2.1. Install Node.js Dependencies

Navigate to the `frontend/` directory and install the required Node.js packages, including `lucide-react` and Tailwind CSS:

```bash
cd frontend
npm install
npm install -D tailwindcss postcss autoprefixer lucide-react
```

### 2.2. Initialize Tailwind CSS

Initialize Tailwind CSS to create `tailwind.config.js` and `postcss.config.js`:

```bash
npx tailwindcss init -p
```

### 2.3. Configure Tailwind CSS

Edit `tailwind.config.js` to configure the `content` paths. Replace the existing `content` array with the following:

```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

### 2.4. Add Tailwind Directives to CSS

Open `frontend/src/index.css` and add the Tailwind directives at the very top of the file, replacing its current content:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

### 2.5. Start Frontend Development Server

Start the React development server:

```bash
npm run dev
```
The frontend will typically run on `http://localhost:5173` (or another available port).

---

**Note:** Ensure both the backend and frontend servers are running simultaneously to use the full application.
